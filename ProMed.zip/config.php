
<?php
$conn = mysqli_connect('localhost','root','','prostore');
if(!$conn){
	echo "not connected";
}
?>  
  