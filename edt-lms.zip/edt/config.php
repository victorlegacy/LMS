<?php
$hostName = "localhost";
$dbuser = "u388683257_edtuse";
$dbPassword = "Hudini60123_";
$dbName = "u388683257_edt";
$conn = mysqli_connect($hostName,$dbuser,$dbPassword ,$dbName);
if (!$conn){
    die("somthing went wrong;");
}

?>